import EventManager from "../../script/engine/utils/EventManager";
import DialogBase from "../../script/engine/uicomponent/DialogBase";
import MusicPrefab from "../../script/engine/uicomponent/MusicPrefab";
import SoundPrefab from "../../script/engine/uicomponent/SoundPrefab";
import PrefabLoader from "../../script/engine/utils/PrefabLoader";
import { GameConfig } from "../../script/game/config/GameConfig";

const { ccclass, property } = cc._decorator;


@ccclass
export default class FishSetting extends DialogBase {

    @property({type:cc.Slider})
    private musicSlider:cc.Slider = null;

    @property({type:cc.Slider})
    private soundSlider:cc.Slider = null;

    onLoadMe(){
        EventManager.instance.addSliderEvent(this.node, this.musicSlider.node, "onMusicSlider", 0);
        EventManager.instance.addSliderEvent(this.node, this.soundSlider.node, "onSoundSlider", 0);
        this.refresh();
    }

    private onMusicSlider(slider: cc.Slider, customEventData) {
        let percent:number = Number(slider.progress.toFixed(3));
        // let maxMoney: number = Math.max(UserInfoModel.userScore - 10, 0)
        // this.nowExchangeNum = Math.floor(maxMoney * this.nowPercent);
        // this.refresh();
        MusicPrefab.changeVolumn(percent);
        this.refresh();
    }

    private onSoundSlider(slider: cc.Slider, customEventData){
        let percent:number = Number(slider.progress.toFixed(3));
        SoundPrefab.changeVolumn(percent);
        this.refresh();
    }

    private refresh(){
        this.musicSlider.progress = MusicPrefab.musicVolumn;
        this.soundSlider.progress = SoundPrefab.soundVolumn;
    }


    public static show(parentNode: cc.Node = null) {
        PrefabLoader.loadPrefab( GameConfig.GameName+"/"+"game/dialog/FishSetting", (loadedResource) => {
            if (!parentNode) {
                parentNode = cc.Canvas.instance.node;
            }
            let node: cc.Node = cc.instantiate(loadedResource);
            parentNode.addChild(node);
            node.setPosition(0, 0)
        });
    }

}
